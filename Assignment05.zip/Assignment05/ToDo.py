#--------------------------
#Title: Manage a To-Do List Using Dictionaries and Lists
#Description: Create text file of to-do items and store in dictionaries and lists
#Original Dev: Lee Deitesfeld
#Change Log:
#20190209LAD Created script
#--------------------------

lst=[]
#When the program starts, load each row of data from the text file into a Python dictionary
objFile = open("Todo.txt", "r")
for strObj in objFile:
    #create list to split and index values
    lstSplit = strObj.split(",")
    strKey = lstSplit[0]
    strValue = lstSplit[1]
    #create dictionary from values in list
    dictItems = {strKey:strValue}

#Add the new dictionary “row” into a Python list object
    lstDict = [(dictItems)]
    for lstDictItem in lstDict:
        lst.append(lstDictItem)
objFile.close()

#Display the contents of the List to the user
objFile = open("Todo.txt", "r")
print("To-Do Items (Task,Priority):")
print("-----------------------------")
for strItems in objFile:
    print(strItems)
objFile.close()

#Allow the user to add or remove tasks from the list using numbered choices
strChoice = None
while strChoice != "5":
    print(
    """
    Menu of Options
    1 - Show current data
    2 - Add a new item
    3 - Remove an existing item
    4 - Save data to file
    5 - Exit program
    """
    )
    strChoice = input("Choice: ")
    print()

    #1 - show current data
    if strChoice == "1":
        #print ongoing list of to-do items
        print(lst)

    #2 - add a new item
    elif strChoice == "2":
        strTask = input("Enter a task: ")
        strPriority = input("Enter a priority: ")
        #add inputs to existing list of dictionary items
        lst.append({strTask:strPriority})
        print(strTask,"and", strPriority, "added")
        print(lst)


    #3 - remove an existing item
    elif strChoice == "3":
        strDeleteTask = input("Which task would you like me to delete?: ")
        #loop through dictionary items in list and remove if inputted value present
        for strDeleteTask in lst:
            if strDeleteTask in lst:
                lst.remove(strDeleteTask)
                print(strDeleteTask, "deleted")
            else:
                print("Sorry, task not in to-do list")
        print(lst)


    #4 - save data to file
    elif strChoice == "4":
        objFile = open("ToDo.txt", "w")
        for lstItem in lst:
            #convert list items to string items in order to clean
            strItem = str(lstItem)
            #clean non-sensical dictionary bits from string items
            strItemReplace1 = strItem.replace("{'","").replace("': '",",")
            strItemReplace2 = strItemReplace1.replace("'}","")
            #write clean values to to-do list txt
            objFile.write(strItemReplace2)
            objFile.write("\n")
        objFile.close()
        print("Data saved to file")

#5 - save data to file and exit program
if strChoice == "5":
        objFile = open("ToDo.txt", "w")
        #print(lst2)
        for item in lst:
            strItem = str(item)
            strItemReplace1 = strItem.replace("{'","").replace("': '",",")
            #objFile.write(strItemReplace1)
            strItemReplace2 = strItemReplace1.replace("'}","")
            objFile.write(strItemReplace2)
            objFile.write("\n")
        objFile.close()
        print("Data saved to file. Good bye")

objFile.close()

