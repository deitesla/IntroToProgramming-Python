import pickle

#Dictionary to pickle
dictFavorites = {
    "Movie": "Amelie",
    "Band": "Radiohead",
    "Ice Cream Flavor": "Rocky Road",
    "Color": "Yellow"}

#Pickling dictionary (write dictionary to binary file)
with open('pickle_favorites.dat', 'wb') as pickle_out:
    pickle.dump(dictFavorites,pickle_out)
pickle_out.close()

#Unpickling dictionary (read binary file created during pickling)
with open('pickle_favorites.dat', 'rb') as pickle_in:
    dictNew_data = pickle.load(pickle_in)

#Print unpickled dictionary
print(dictNew_data, "\n")

print("My Favorite Things: \n")
print("- ",dictNew_data["Movie"])
print("- ",dictNew_data["Band"])
print("- ",dictNew_data["Ice Cream Flavor"])
print("- ",dictNew_data["Color"])
