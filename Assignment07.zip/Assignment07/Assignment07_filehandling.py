#attempt to open the cat.txt file
try:
    objFile = open("cat.txt", "r")
    print("File opened.")

#report error if cat.txt file does not exist
except:
    print("The file you are attempting to open does not exist.")
