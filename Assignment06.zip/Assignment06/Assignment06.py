#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   LDeitesfeld, 02/14/2019, Modified script to include class and methods

#-------------------------------------------------#

#-- DATA --#
# declare variables and constants
# objFile = An object that represents a file
objFileName = "Todo.txt"
# lstData = A row of text data from the file
lstData = ""
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {}
# lstTable = A dictionary that acts as a 'table' of rows
lstTable = []
# strMenu = A menu of user options
strMenu = """
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """
strChoice = ""

# -- DECLARE CLASS -- #
class ToDo(object):

    #-- PROCESSING METHODS --#
    @staticmethod
    def LoadDict():
        '''This function loads info from todo.txt into a dictionary'''
        objFile = open(objFileName, "r")
        for line in objFile:
            lstData = line.split(",") # readline() reads a line of the data into 2 elements
            dicRow = {"Task":lstData[0].strip(), "Priority":lstData[1].strip()} #strip removes the extra spaces
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

    @staticmethod
    def AddToDict():
        '''This function adds a task & priority to the dictionary'''
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)
        return lstTable

    @staticmethod
    def RemoveFromDict():
        '''This function removes a task & priority from the dictionary'''
        strTaskToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False #Creating a boolean Flag
        intRowNumber = 0
        while(intRowNumber < len(lstTable)):
            if(strTaskToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])):
            #the values function creates a list!
            #creates a list, converts it to a string, converts to a 'list' so it can use the index at the end of the line
                del lstTable[intRowNumber]
                blnItemRemoved = True
                #end if
                intRowNumber += 1
            #end for loop
            #5b-Update user on the status
            if(blnItemRemoved == True):
                print("The task was removed.")
            else:
                print("I'm sorry, but I could not find that task.")
            break

    @staticmethod
    def SaveTasks():
        '''This function saves the current dictionary to todo.txt'''
        #5a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
        #for each row, extract the task and priority and save it to the file
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("\n")
        #5b Ask if they want save that data
        if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
                objFile.close()
                print("Data saved to file!")
        else:
            print("New data was NOT Saved, but previous data still exists!.")



    #-- PRESENTATION METHODS --#
    @staticmethod
    def ShowMenu():
            '''This function displays the menu of options'''
            print (strMenu)

    @staticmethod
    def CurrentData():
        '''This function displays the current items in the dictionary'''
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")



#---INPUT/OUTPUT---#

ToDo.LoadDict()

while(True):
    ToDo.ShowMenu()
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    if strChoice == '1':
        ToDo.CurrentData()
    elif strChoice == '2':
        ToDo.AddToDict()
    elif strChoice == '3':
        ToDo.RemoveFromDict()
    elif strChoice == '4':
        ToDo.SaveTasks()
    elif strChoice == '5':
        break
